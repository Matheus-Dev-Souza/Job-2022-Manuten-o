var btnApagar = document.getElementsByClassName('btnApagar');
var fecharModalApagar = document.getElementsByClassName('fecharModalApagar');
var modalApagar = document.getElementsByClassName('modalApagar');

for (let i = 0; i < btnApagar.length; i++) {
    btnApagar[i].addEventListener('click', () => {
        modalApagar[i].style.display = 'flex';
    });
    fecharModalApagar[i].addEventListener('click', () => {
        modalApagar[i].style.display = 'none';
    });
}