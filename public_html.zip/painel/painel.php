<?php

if (isset($_SESSION['logado']) && $_SESSION['logado'] ==  true) {
    //ok
} else {
    echo '<script>location.href = "https://setebit.com.br/painel"; </script>';
}

if (isset($_POST['btnSair'])) {
    $_SESSION['user'] = "";
    $_SESSION['logado'] = false;
    echo "<meta HTTP-EQUIV='refresh' CONTENT='0'>";
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel | setebit</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css">
</head>

<body>

    <header>
        <div class="left">
            <form method="post">
                <input class="btnSair" name="btnSair" type="submit" value="Sair">
            </form>
        </div>
        <div class="user">
            <i class="bi bi-person-circle"></i>
            <h5><?php echo $_SESSION['user']; ?></h5>
        </div>
    </header>

    <section id="ctnContatos">

        <div class="title">
            <div class="info">
                <p>Nome</p>
            </div>
            <div class="info">
                <p>Número</p>
            </div>
            <div class="info">
                <p>Momento</p>
            </div>
            <div class="info">
                <p>IP</p>
            </div>
            <div class="info acoes">
                <p>Ações</p>
            </div>
        </div>

        <?php include('contatos.php'); ?>

    </section>

    <footer>
        <h5>Feito por <a target="_blank" href="https://viniciushnf.com/">Vinicius Henrique</a></h5>
    </footer>

</body>
<script src="script.js"></script>

</html>