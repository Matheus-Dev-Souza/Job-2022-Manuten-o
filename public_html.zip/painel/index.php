<?php

include('config.php');
session_start();

if (isset($_SESSION['logado']) && $_SESSION['logado'] ==  true) {
    include('painel.php');
} else {
    include('login.php');
}