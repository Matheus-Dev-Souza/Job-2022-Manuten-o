<?php

if (isset($_POST['logar'])) {
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    $sql = $pdo->prepare("SELECT * FROM usuarios WHERE login=? AND senha=?");
    $sql->execute(array($login, $senha));
    $info = $sql->fetchAll();

    if (count($info) > 0) {
        foreach ($info as $key => $value) {
        }
        $_SESSION['user'] = $value['nome'];
        $_SESSION['logado'] = true;
        echo "<meta HTTP-EQUIV='refresh' CONTENT='0'>";
    } else {
        echo '<div id="erroLogin"><h4><i class="bi bi-exclamation-triangle"></i> Login ou senha incorretos!</h4></div>';
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | setebit</title>
    <link rel="stylesheet" href="login.css">
</head>

<body>

    <section>
        <div class="box">
            <h1>Login</h1>
            <form method="post">
                <input type="text" name="login" placeholder="Login">
                <input type="password" name="senha" placeholder="Senha">
                <input type="submit" value="Logar" name="logar">
            </form>
        </div>
    </section>

    <footer>
        <h5>Feito por <a target="_blank" href="https://viniciushnf.com/">Vinicius Henrique</a></h5>
    </footer>

</body>

</html>