<?php

$sqlCtt = $pdo->prepare("SELECT * FROM contatos ORDER BY id DESC");
$sqlCtt->execute();
$infoCtt = $sqlCtt->fetchAll();

foreach ($infoCtt as $keyCtt => $valueCtt) {
    $id = $valueCtt['id'];
    if (isset($_POST['apagar_' . $id])) {
        $sql = $pdo->prepare("DELETE FROM `contatos` WHERE id=?");
        if ($sql->execute(array($id))) {
            echo "<meta HTTP-EQUIV='refresh' CONTENT='0'>";
        }
    }

    $wpp = str_replace(' ', '', $valueCtt['numero']);
?>

<div class="box">
    <div class="info">
        <h6 class="desc">Nome:</h6>
        <p><?php echo $valueCtt['nome'] ?></p>
    </div>
    <div class="info">
        <h6 class="desc">Número:</h6>
        <p><?php echo $valueCtt['numero'] ?></p>
    </div>
    <div class="info momento">
        <h6 class="desc">Momento:</h6>
        <p><?php echo $valueCtt['momento'] ?></p>
    </div>
    <div class="info ip">
        <h6 class="desc">IP:</h6>
        <p><?php echo $valueCtt['ip'] ?></p>
    </div>
    <div class="info acoes">
        <a target="_blank" href="https://api.whatsapp.com/send?phone=55<?php echo $wpp ?>" class="btn wpp">
            <i class="bi bi-whatsapp"></i></a>
        <a target="_blank" href="tel:<?php echo $valueCtt['numero'] ?>" class="btn tel"><i
                class="bi bi-telephone"></i></a>
        <div class="btn del btnApagar"><i class="bi bi-trash"></i></div>
    </div>

    <div class="modalApagar">
        <div class="box">
            <h3>Deseja realmente apagar as informações deste contato?</h3>
            <p>Nome: <?php echo $valueCtt['nome'] ?></p>
            <p>Número: <?php echo $valueCtt['numero'] ?></p>
            <div class="bottom">
                <form method="post">
                    <div class="nao fecharModalApagar">Não</div>
                    <input type="submit" value="Apagar" name="apagar_<?php echo $valueCtt['id'] ?>">
                </form>
            </div>
        </div>
    </div>
</div>

<?php } ?>