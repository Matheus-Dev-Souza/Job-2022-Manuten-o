const modal = document.getElementById('modal');

var btnAbrirModal = document.getElementsByClassName('abrirModal');
for (let i = 0; i < btnAbrirModal.length; i++) {
    btnAbrirModal[i].addEventListener('click', () => {
        modal.style.display = 'flex';
    });
}

const closeModal = document.getElementById('closeModal');
closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
})