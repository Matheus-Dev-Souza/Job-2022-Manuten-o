<?php

include('config.php');

if (isset($_POST['inscrever'])) {
    $nome = $_POST['inNome'];
    $numero = $_POST['inNumero'];

    if ($nome != '') {
        if ($numero != '') {
            date_default_timezone_set('America/Sao_Paulo');
            $momento = date('d-m-Y H:i:s');
            $ip = $_SERVER["REMOTE_ADDR"];

            $sql = $pdo->prepare("INSERT INTO `contatos` VALUES (null,?,?,?,?)");
            $sql->execute(array($nome, $numero, $momento, $ip));

            echo "
                <div class='msgDB sucesso'>
                    <h5>Enviado com sucesso!</h5>
                </div>
                <script>
                setTimeout(() => {
                    document.getElementById('cntMsg').innerHTML = '';
                }, 6000);
                </script>
            ";
        } else {
            echo "
                <div class='msgDB alerta'>
                    <h5>Preencha o Número!</h5>
                </div>
                <script>
                setTimeout(() => {
                    document.getElementById('cntMsg').innerHTML = '';
                }, 6000);
                </script>
            ";
        }
    } else {
        echo "
            <div class='msgDB alerta'>
                <h5>Preencha o Nome!</h5>
            </div>
            <script>
            setTimeout(() => {
                document.getElementById('cntMsg').innerHTML = '';
            }, 6000);
            </script>
        ";
    }
}