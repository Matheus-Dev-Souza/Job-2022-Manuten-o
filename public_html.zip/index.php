<!-- Feito por Vinicius Henrique -->
<!-- https://viniciushnf.com/ -->

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '572322324620451');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=572322324620451&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>setebit</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="imagens/logo.png" type="image/x-icon">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css">

    <meta name="title" content="{setebit}">
    <meta name="description" content="Tome decisões mais inteligentes, com dados precisos, completos e em tempo real com um sistema de gestão
    empresarial intuitivo para os apostadores.">

    <meta property="og:type" content="website">
    <meta property="og:url" content="http://setebit.com.br/">
    <meta property="og:title" content="{setebit}">
    <meta property="og:description" content="Tome decisões mais inteligentes, com dados precisos, completos e em tempo real com um sistema de gestão
    empresarial intuitivo para os apostadores.">
    <meta property="og:image" content="imagens/logo.png">
    <meta property="og:image:type" content="image/png">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="http://setebit.com.br/">
    <meta property="twitter:title" content="{setebit}">
    <meta property="twitter:description" content="Tome decisões mais inteligentes, com dados precisos, completos e em tempo real com um sistema de gestão
    empresarial intuitivo para os apostadores.">
    <meta property="twitter:image" content="">
    <meta property="twitter:image" content="imagens/logo.png">

    <meta name="facebook-domain-verification" content="70pm0f6qvy0os2mhuz7wom160rirrt" />

    <!-- Google Tag Manager -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-KC45NMJ');
    </script>
    <!-- End Google Tag Manager -->

</head>

<body>


    <div id="cntMsg">
        <?php
        // include('inscrever.php'); 
        ?>
    </div>

    <div id="modal">
        <div class="box">
            <div id="closeModal" class="close">
                <i class="bi bi-x-circle"></i>
            </div>
            <h3>Preencha seus dados que a Setebit entrará imediatamente em contato com você</h3>
            <form method="post">
                <input type="text" name="inNome" placeholder="Nome">
                <input type="text" name="inNumero" placeholder="Número">
                <input type="submit" value="Enviar" name="inscrever">
            </form>
        </div>
    </div>

    <section id="sec1">
        <div class="logo">
            <h1>{setebit}</h1>
        </div>

        <div class="text">
            <p>Tome decisões mais inteligentes, com dados precisos, completos e em tempo real com um sistema de gestão
                empresarial intuitivo para os apostadores.</p>
        </div>

        <div class="videoYT">
            <div style="padding:56.25% 0 0 0;position:relative;"><iframe
                    src="https://player.vimeo.com/video/644965614?h=1a007516e5&amp;badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479"
                    frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen
                    style="position:absolute;top:0;left:0;width:100%;height:100%;" title="MVI_1044"></iframe></div>
            <script src="https://player.vimeo.com/api/player.js"></script>
        </div>

        <div class="cta">
            <a href="https://api.whatsapp.com/send?phone=5511973185939&text=Ol%C3%A1%2C%20vim%20do%20site%20e%20quero%20saber%20mais%20sobre%20o%20sistema"
                class="btn">Quero ser dono do meu próprio negócio</a>
        </div>
    </section>

    <section id="sec2">
        <h2>Benefícios</h2>

        <div class="ctn">
            <div class="box">
                <img src="imagens/notebook.png" alt="">
                <h5>O sistema de Gestão que otimizará sua rotina!</h5>
                <p>Permitindo que você tenha uma visão ampla dos processos, além de trazer recursos para que você tome
                    suas decisões da forma mais estratégica e inteligente possível em suas apostas.</p>
            </div>
            <div class="box">
                <img src="imagens/maquineta.png" alt="">
                <h5>O Sistema esportivo na palma da sua mão!</h5>
                <p>Uma plataforma que proporcione o acompanhamento, automatização e otimização dos processos gerenciais
                    inerentes ao esporte.</p>
            </div>
            <div class="box">
                <img src="imagens/celular.png" alt="">
                <h5>Acompanhe em tempo real seus resultados!</h5>
                <p>A solução é um sistema de gestão esportiva capaz de validar automaticamente todos os processos em um
                    lugar só, ganhando tempo para se dedicar a outras questões. Acesse de forma simplificada, rápida,
                    prática e segura. </p>
            </div>
        </div>
    </section>

    <section id="sec3">
        <h2>Sistemas</h2>

        <div class="box">
            <div class="left">
                <div class="bg">
                    <h5>JB</h5>
                </div>
            </div>
            <div class="right">
                <p>A plataforma para acessar todas as informações principais da sua empresa, de uma maneira visual muito
                    simples de entender pelo notebook, celular e tablet. O sistema funciona em período de 24hrs por dia,
                    7 dias por semana. Assim, sobra mais tempo para focar seu tempo e energia em suas apostas.</p>
            </div>
        </div>

        <div class="box">
            <div class="left">
                <div class="bg">
                    <h5>BETS</h5>
                </div>
            </div>
            <div class="right">
                <p>A plataforma para smartphones e tablets, mais segura e operacional do mercado para fazer seus lances.
                    Onde poderá obter informações sobre os desempenhos de equipes e atletas que estarão envolvidos em
                    uma partida ou competição. Tudo isto está ao alcance de poucos cliques em seu aparelho celular. </p>
            </div>
        </div>
    </section>

    <section id="sec4">
        <h3>Você tá esperando o que <br class="mob"> pra fazer sua aposta? <br class="desk"> VEM COM A GENTE</h3>

        <div class="cta">
            <a href="https://api.whatsapp.com/send?phone=5511973185939&text=Ol%C3%A1%2C%20vim%20do%20site%20e%20quero%20saber%20mais%20sobre%20o%20sistema"
                class="btn">Quero ser dono do meu próprio negócio</a>
        </div>
    </section>

    <section id="sec5">
        <h3>Nossos parceiros</h3>

        <div class="ctn">
            <div class="box">
                <img src="imagens/p1.png" alt="">
            </div>
            <div class="box">
                <img src="imagens/p2.png" alt="">
            </div>
            <div class="box">
                <img src="imagens/p3.png" alt="">
            </div>
            <div class="box">
                <img src="imagens/p4.png" alt="">
            </div>
            <div class="box">
                <img src="imagens/p5.png" alt="">
            </div>
            <div class="box">
                <img src="imagens/p6.png" alt="">
            </div>
        </div>
    </section>

    <div id="wpp">
        <a href="https://api.whatsapp.com/send?phone=5511973185939" target="_blank" rel="noopener noreferrer">
            <img src="imagens/wpp.png" alt="">
        </a>
    </div>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KC45NMJ" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

</body>

<script src="script.js"></script>

</html>